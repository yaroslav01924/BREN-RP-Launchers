package com.crmp.mobile.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.crmp.mobile.download.CacheStatus
import com.crmp.mobile.download.DownloadState
import com.crmp.mobile.ui.components.CacheDownloadCard
import com.crmp.mobile.viewmodel.AppUiState

private val BrenBlack = Color(0xFF090A0D)
private val BrenPanel = Color(0xFF17191F)
private val BrenGold = Color(0xFFD6AD55)
private val BrenMutedGold = Color(0xFF8F7440)
private val BrenText = Color(0xFFF4F0E7)
private val BrenMuted = Color(0xFFAAA49A)

@Composable
fun HomeScreen(
    state: AppUiState,
    downloadState: DownloadState,
    cacheStatus: CacheStatus,
    onLaunch: () -> Unit,
    onOpenServers: () -> Unit,
    onDownloadCache: () -> Unit,
    onCancelDownload: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF19150E), BrenBlack, Color(0xFF08090B))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(
                        text = "BREN",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Black,
                        color = BrenGold,
                    )
                    Text(
                        text = "ROLEPLAY  •  MOBILE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = BrenMuted,
                    )
                }
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFF292216),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BrenMutedGold),
                ) {
                    Text(
                        text = "BETA",
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        color = BrenGold,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "ТВОЯ ИСТОРИЯ НАЧИНАЕТСЯ ЗДЕСЬ",
                    style = MaterialTheme.typography.titleMedium,
                    color = BrenText,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = "Добро пожаловать в BREN RP",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BrenMuted,
                )
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = BrenPanel),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF554326)),
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = "ПРОФИЛЬ ИГРОКА",
                            style = MaterialTheme.typography.labelMedium,
                            color = BrenGold,
                            fontWeight = FontWeight.Bold,
                        )
                        Surface(shape = CircleShape, color = Color(0xFF263326)) {
                            Text(
                                text = "● ГОТОВ",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                color = Color(0xFF9BCB91),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                    Text(
                        text = state.nickname,
                        style = MaterialTheme.typography.headlineSmall,
                        color = BrenText,
                        fontWeight = FontWeight.Bold,
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color(0xFF393027))
                    )
                    Text(
                        text = "ВЫБРАННЫЙ СЕРВЕР",
                        style = MaterialTheme.typography.labelSmall,
                        color = BrenMuted,
                        fontWeight = FontWeight.Bold,
                    )
                    val server = state.selectedServer
                    if (server != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Dns,
                                contentDescription = null,
                                tint = BrenGold,
                                modifier = Modifier.size(22.dp),
                            )
                            Spacer(Modifier.size(10.dp))
                            Column {
                                Text(
                                    text = server.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = BrenText,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Text(
                                    text = server.endpoint(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = BrenMuted,
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "Сервер не выбран",
                            color = Color(0xFFE39A8E),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }

            Button(
                onClick = onLaunch,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),
                shape = RoundedCornerShape(17.dp),
                enabled = state.selectedServer != null,
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrenGold,
                    contentColor = Color(0xFF17120A),
                    disabledContainerColor = Color(0xFF51452E),
                    disabledContentColor = Color(0xFFB7A985),
                ),
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text(
                    text = "ИГРАТЬ",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                )
            }

            OutlinedButton(
                onClick = onOpenServers,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = BrenGold),
                border = androidx.compose.foundation.BorderStroke(1.dp, BrenMutedGold),
            ) {
                Text("ВЫБРАТЬ СЕРВЕР", fontWeight = FontWeight.Bold)
            }

            CacheDownloadCard(
                downloadState = downloadState,
                cacheStatus = cacheStatus,
                onDownload = onDownloadCache,
                onCancel = onCancelDownload,
            )

            Text(
                text = "BREN RP MOBILE  •  ТВОЙ ГОРОД. ТВОИ ПРАВИЛА.",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 2.dp, bottom = 10.dp),
                style = MaterialTheme.typography.labelSmall,
                color = BrenMuted,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = "Игровые данные GTA SA не входят в приложение. Используйте только легально полученный игровой кэш.",
                style = MaterialTheme.typography.bodySmall,
                color = BrenMuted,
            )
        }
    }
}
