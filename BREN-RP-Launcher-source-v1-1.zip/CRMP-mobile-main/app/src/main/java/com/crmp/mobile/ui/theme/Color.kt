package com.crmp.mobile.ui.theme

import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFFD6AD55)
val GreenLight = Color(0xFFE7C879)
val GreenDark = Color(0xFF8F6B2D)
val BgDark = Color(0xFF090A0D)
val SurfaceDark = Color(0xFF17191F)
val SurfaceElevated = Color(0xFF242329)
val TextPrimary = Color(0xFFF4F0E7)
val TextSecondary = Color(0xFFAAA49A)
val AccentAmber = Color(0xFFD6AD55)
val Danger = Color(0xFFCF6679)
